package Day1;

public class arthemetic {
    public static void main(String[] args) {
        int a = 20 ;
        int b = 30 ; 

        // Arthemetic Operator
        System.out.println("Addition = " + (a+b));
        System.out.println("Substraction = " + (a - b));
        System.out.println("Multiplication = " + (a * b));
        System.out.println("Division = " + (a / b));
        System.out.println("Module = " + (a % b));


        // Relation Operation
        System.out.println("Equal = " + (a == b));
        System.out.println("Not Equal = " + (a != b));
        System.out.println("Greater than = " + (a > b));
        System.out.println("Leass than = " + (a < b));
        System.out.println("Greater than equal to = " + (a >= b));
        System.out.println("Greater than equal to = " + (a <= b));

    }
}
